import { ActiveUserPipePipe } from './active-user-pipe.pipe';

describe('ActiveUserPipePipe', () => {
  it('create an instance', () => {
    const pipe = new ActiveUserPipePipe();
    expect(pipe).toBeTruthy();
  });
});
