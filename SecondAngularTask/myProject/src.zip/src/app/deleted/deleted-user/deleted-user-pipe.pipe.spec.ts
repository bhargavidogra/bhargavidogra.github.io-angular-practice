import { DeletedUserPipePipe } from './deleted-user-pipe.pipe';

describe('DeletedUserPipePipe', () => {
  it('create an instance', () => {
    const pipe = new DeletedUserPipePipe();
    expect(pipe).toBeTruthy();
  });
});
