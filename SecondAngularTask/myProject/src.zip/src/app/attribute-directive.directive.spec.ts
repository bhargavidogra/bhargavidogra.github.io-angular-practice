import { AttributeDirectiveDirective } from './attribute-directive.directive';

describe('AttributeDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new AttributeDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
