import { AttributeisActiveDirective } from './attributeis-active.directive';

describe('AttributeisActiveDirective', () => {
  it('should create an instance', () => {
    const directive = new AttributeisActiveDirective();
    expect(directive).toBeTruthy();
  });
});
